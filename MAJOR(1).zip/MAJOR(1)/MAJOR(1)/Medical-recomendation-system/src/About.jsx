import React from "react";
import './About.css';  // You can create and import a CSS file for styling

// About page component
function About() {
  return (
    <div className="about-page">
      <div className="about-content">
        <h1>Why Smart Disease Prediction System?</h1>
        <p>
          In today’s world, health is one of the most important aspects of life. With advancements in technology, the Smart Disease Prediction System aims to provide quick and accurate predictions based on symptoms entered by users. This system can potentially help in early diagnosis and prevent future health risks, providing personalized recommendations for treatment and lifestyle changes.
        </p>
        <p>
          Our goal is to bring healthcare to your fingertips, making it accessible and convenient for anyone, anywhere. The system uses cutting-edge algorithms and machine learning models to predict diseases based on the symptoms provided.
        </p>
      </div>

      <div className="team-section">
        <h2>Meet the Team</h2>
        <div className="team-cards">
          <div className="card">
            <img src="/Adesh.png" alt="Adesh Rajput" className="team-member-img"/>
            <h3>Adesh rajput</h3>
            <p>Lead Developer</p>
          </div>
          <div className="card">
            <img src="/Shalini.png" alt="Shalini Singh" className="team-member-img"/>
            <h3>Shalini Singh</h3>
            <p>Data Scientist</p>
          </div>
          <div className="card">
            <img src="/Pratibha.png" alt="Pratibha Tyagi" className="team-member-img"/>
            <h3>Pratibha Tyagi</h3>
            <p>UI/UX Designer</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default About;
