import { useState } from "react";
import './form.css';

export default function Form() {
  const [symptoms, setSymptoms] = useState("");
  const [result, setResult] = useState(null);

  const handleInput = (event) => {
    setSymptoms(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    // prepare data to send
    const data = { input: symptoms };

    try {
      const response = await fetch("http://localhost:5000/predict", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      setResult(result);
      console.log("Result:", result);
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <>
      {/* Navbar */}
      <nav className="navbar">
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/about">About</a></li>
          <li><a href="/login">Login</a></li>
          <li><a href="/register">Register</a></li>
        </ul>
      </nav>

      {/* Form for symptoms input */}
      <div className="form-container">
        <form onSubmit={handleSubmit}>
          <label htmlFor="symptoms">Type your symptoms:</label>
          <input
            type="text"
            name="symptoms"
            value={symptoms}
            placeholder="Use symptoms like itching, vomiting, coughing"
            onChange={handleInput}
          />
          <button type="submit">Submit</button>
        </form>
      </div>

      {/* Display results in cards */}
      {result && (
        <div className="result-container">
          <div className="card">
            <h3>Predicted Disease</h3>
            <p>{result.predicted_disease}</p>
          </div>

          <div className="card">
            <h3>Description</h3>
            <p>{result.description}</p>
          </div>

          <div className="card">
            <h3>Diet</h3>
            <p>{result.diets}</p>
          </div>

          <div className="card">
            <h3>Medications</h3>
            <p>{result.medications}</p>
          </div>

          <div className="card">
            <h3>Precautions</h3>
            <p>{result.precautions}</p>
          </div>

          <div className="card">
            <h3>Workout</h3>
            <p>{result.workout}</p>
          </div>
        </div>
      )}
    </>
  );
}
