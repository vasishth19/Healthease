import React, { useState, useEffect } from 'react';
import './App.css'
import Form from './form';
import About from './About';
import Login from './Login';
import Register from './Register';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
function App() {
  return (
    <>
       <Router>
      <div>
        {/* Navbar */}
        <nav className="navbar">
          <ul>
            <li><a href="/">Home</a></li>
            <li><a href="/about">About</a></li>
            <li><a href="/login">Login</a></li>
            <li><a href="/register">Register</a></li>
          </ul>
        </nav>

        {/* Routes for different pages */}
        <Routes>
          <Route path="/" element={<Form />} />
          <Route path="/about" element={<About />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/predict" element={<Form />} /> {/* Keep the form route */}
        </Routes>
      </div>
    </Router>
    </>
  );
}

export default App
